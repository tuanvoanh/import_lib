from django.apps import AppConfig


class DataImportConfig(AppConfig):
    name = 'plat_import_lib_api'
